sudo make clean
sudo make
sudo make install
sudo modprobe 8192du
