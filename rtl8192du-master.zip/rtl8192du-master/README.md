rtl8192du
=========

Source code for RTL8192DU device
